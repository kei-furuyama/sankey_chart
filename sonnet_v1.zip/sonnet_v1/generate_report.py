#!/usr/bin/env python3
"""
子育て・介護関係26手続のオンライン化取組状況 — report.json generator (Sonnet v1)

Page 1: 都道府県一覧  — ヘッダー + 左サマリーパネル + 47都道府県タイル
Page 2: 市区町村一覧  — ヘッダー + スライサー + 左パネル + マトリクステーブル
"""

import json
import os
import sys

# ============================================================
# デザイン定数
# ============================================================
BG_WHITE   = "#FFFFFF"
BG_PANEL   = "#F8F8FB"
GRAY_LINE  = "#D8D8DB"
TXT_MAIN   = "#1A1A1A"
TXT_SUB    = "#666666"
TXT_MUTED  = "#999999"
BLUE       = "#0017C1"
RADIUS     = 20

TITLE    = "子育て・介護関係26手続きのオンライン化取組状況"
DATE_STR = "2026年3月時点の数値"

# 地域ブロック → 都道府県リスト（地理順）
REGIONS = [
    ("北海道・東北", ["北海道", "青森県", "岩手県", "宮城県", "秋田県", "山形県", "福島県"]),
    ("関東",         ["茨城県", "栃木県", "群馬県", "埼玉県", "千葉県", "東京都", "神奈川県"]),
    ("中部",         ["新潟県", "富山県", "石川県", "福井県", "山梨県", "長野県",
                      "岐阜県", "静岡県", "愛知県"]),
    ("近畿",         ["三重県", "滋賀県", "京都府", "大阪府", "兵庫県", "奈良県", "和歌山県"]),
    ("中国・四国",   ["鳥取県", "島根県", "岡山県", "広島県", "山口県",
                      "徳島県", "香川県", "愛媛県", "高知県"]),
    ("九州・沖縄",   ["福岡県", "佐賀県", "長崎県", "熊本県", "大分県",
                      "宮崎県", "鹿児島県", "沖縄県"]),
]


# ============================================================
# JSON プリミティブヘルパー
# ============================================================

def lit(v):
    return {"expr": {"Literal": {"Value": v}}}

def lit_str(s):
    return lit(f"'{s}'")

def lit_bool(b):
    return lit("true" if b else "false")

def lit_int(n):
    return lit(f"{n}L")

def lit_double(n):
    return lit(f"{n}D")

def solid(c):
    return {"solid": {"color": lit_str(c)}}

def pos(x, y, z, w, h, tab=0):
    return {"x": x, "y": y, "z": z, "width": w, "height": h, "tabOrder": tab}

def vc(config, filters, x, y, w, h, z):
    return {
        "config":  json.dumps(config,  ensure_ascii=False),
        "filters": json.dumps(filters, ensure_ascii=False),
        "height": float(h),
        "width":  float(w),
        "x": float(x),
        "y": float(y),
        "z": float(z),
    }

HIDE = [{"properties": {"show": lit_bool(False)}}]


# ============================================================
# ビジュアルビルダー
# ============================================================

def textbox(name, x, y, w, h, z, paragraphs):
    cfg = {
        "name": name,
        "layouts": [{"id": 0, "position": pos(x, y, z, w, h)}],
        "singleVisual": {
            "visualType": "textbox",
            "objects": {"general": [{"properties": {
                "paragraphs": lit(json.dumps({"paragraphs": paragraphs}, ensure_ascii=False)),
            }}]},
            "vcObjects": {
                "title": HIDE, "background": HIDE,
                "border": HIDE, "visualHeader": HIDE,
            },
        },
    }
    return vc(cfg, [], x, y, w, h, z)


def shape(name, x, y, w, h, z, fill=BG_PANEL, border=BG_PANEL, radius=RADIUS):
    cfg = {
        "name": name,
        "layouts": [{"id": 0, "position": pos(x, y, z, w, h)}],
        "singleVisual": {
            "visualType": "shape",
            "objects": {
                "line": [{"properties": {
                    "lineColor":  solid(border),
                    "weight":     lit_double(1),
                    "roundEdge":  lit_int(radius),
                }}],
                "fill": [{"properties": {
                    "fillColor":    solid(fill),
                    "transparency": lit_double(0),
                }}],
            },
            "vcObjects": {
                "title": HIDE, "background": HIDE,
                "border": HIDE, "visualHeader": HIDE,
            },
        },
    }
    return vc(cfg, [], x, y, w, h, z)


def card_measure(name, x, y, w, h, z, measure, table="オンライン化状況",
                 font_size=28, color=TXT_MAIN):
    ref = f"t.{measure}"
    cfg = {
        "name": name,
        "layouts": [{"id": 0, "position": pos(x, y, z, w, h)}],
        "singleVisual": {
            "visualType": "card",
            "projections": {"Values": [{"queryRef": ref}]},
            "prototypeQuery": {
                "Version": 2,
                "From": [{"Name": "t", "Entity": table, "Type": 0}],
                "Select": [{"Measure": {
                    "Expression": {"SourceRef": {"Source": "t"}},
                    "Property": measure,
                }, "Name": ref}],
            },
            "objects": {
                "labels": [{"properties": {
                    "fontSize":   lit_double(font_size),
                    "color":      solid(color),
                    "fontFamily": lit_str("Arial"),
                }}],
                "categoryLabels": [{"properties": {"show": lit_bool(False)}}],
            },
            "vcObjects": {
                "title": HIDE, "background": HIDE,
                "border": HIDE, "visualHeader": HIDE,
            },
        },
    }
    return vc(cfg, [], x, y, w, h, z)


def donut(name, x, y, w, h, z, font_size=36):
    cfg = {
        "name": name,
        "layouts": [{"id": 0, "position": pos(x, y, z, w, h)}],
        "singleVisual": {
            "visualType": "donutChart",
            "projections": {
                "Category": [{"queryRef": "k.ステータス"}],
                "Y":        [{"queryRef": "k.完了状況値"}],
            },
            "prototypeQuery": {
                "Version": 2,
                "From": [{"Name": "k", "Entity": "完了状況", "Type": 0}],
                "Select": [
                    {"Column":  {"Expression": {"SourceRef": {"Source": "k"}},
                                 "Property": "ステータス"},
                     "Name": "k.ステータス"},
                    {"Measure": {"Expression": {"SourceRef": {"Source": "k"}},
                                 "Property": "完了状況値"},
                     "Name": "k.完了状況値"},
                ],
                "OrderBy": [{"Direction": 1, "Expression": {
                    "Column": {"Expression": {"SourceRef": {"Source": "k"}},
                               "Property": "順序"}}}],
            },
            "objects": {
                "legend": [{"properties": {"show": lit_bool(False)}}],
                "dataPoint": [
                    {"properties": {"fill": solid(BLUE)},
                     "selector": {"data": [{"scopeId": {"Comparison": {
                         "ComparisonKind": 0,
                         "Left":  {"Column": {"Expression": {"SourceRef": {"Entity": "完了状況"}},
                                              "Property": "ステータス"}},
                         "Right": {"Literal": {"Value": "'完了'"}},
                     }}}]}},
                    {"properties": {"fill": solid(GRAY_LINE)},
                     "selector": {"data": [{"scopeId": {"Comparison": {
                         "ComparisonKind": 0,
                         "Left":  {"Column": {"Expression": {"SourceRef": {"Entity": "完了状況"}},
                                              "Property": "ステータス"}},
                         "Right": {"Literal": {"Value": "'未完了'"}},
                     }}}]}},
                ],
                "labels": [{"properties": {
                    "show":        lit_bool(True),
                    "labelStyle":  lit_str("Percent of total"),
                    "fontSize":    lit_double(font_size),
                    "color":       solid(TXT_MAIN),
                    "fontFamily":  lit_str("Arial"),
                }}],
                "slices": [{"properties": {"innerRadiusRatio": lit_int(82)}}],
            },
            "vcObjects": {
                "title": HIDE, "background": HIDE,
                "border": HIDE, "visualHeader": HIDE,
            },
        },
    }
    return vc(cfg, [], x, y, w, h, z)


def pref_tile(name, x, y, w, h, z, pref_name):
    ref = "o.子育て介護26手続完了率"
    cfg = {
        "name": name,
        "layouts": [{"id": 0, "position": pos(x, y, z, w, h)}],
        "singleVisual": {
            "visualType": "card",
            "projections": {"Values": [{"queryRef": ref}]},
            "prototypeQuery": {
                "Version": 2,
                "From": [{"Name": "o", "Entity": "オンライン化状況", "Type": 0}],
                "Select": [{"Measure": {
                    "Expression": {"SourceRef": {"Source": "o"}},
                    "Property": "子育て介護26手続完了率",
                }, "Name": ref}],
            },
            "objects": {
                "labels": [{"properties": {
                    "fontSize":   lit_double(16),
                    "color":      solid(TXT_MAIN),
                    "fontFamily": lit_str("Arial"),
                }}],
                "categoryLabels": [{"properties": {"show": lit_bool(False)}}],
            },
            "vcObjects": {
                "title": [{"properties": {
                    "show":       lit_bool(True),
                    "text":       lit_str(pref_name),
                    "fontColor":  solid(TXT_MAIN),
                    "fontSize":   lit_double(12),
                    "fontFamily": lit_str("Arial"),
                    "bold":       lit_bool(True),
                }}],
                "background": HIDE, "border": HIDE,
                "visualHeader": HIDE,
                "padding": [{"properties": {
                    "top":    lit_double(2),
                    "bottom": lit_double(2),
                    "left":   lit_double(4),
                    "right":  lit_double(4),
                }}],
            },
        },
    }
    filters = [{
        "name": f"flt_{name}",
        "expression": {
            "Column": {
                "Expression": {"SourceRef": {"Entity": "オンライン化状況"}},
                "Property": "都道府県",
            }
        },
        "type": "Categorical",
        "filter": {
            "Version": 2,
            "From": [{"Name": "o", "Entity": "オンライン化状況", "Type": 0}],
            "Where": [{"Condition": {"Comparison": {
                "ComparisonKind": 0,
                "Left":  {"Column": {"Expression": {"SourceRef": {"Source": "o"}},
                                     "Property": "都道府県"}},
                "Right": {"Literal": {"Value": f"'{pref_name}'"}},
            }}}],
        },
        "isHiddenInViewMode": True,
    }]
    return vc(cfg, filters, x, y, w, h, z)


def slicer(name, x, y, w, h, z, column, label, single=True):
    ref = f"o.{column}"
    cfg = {
        "name": name,
        "layouts": [{"id": 0, "position": pos(x, y, z, w, h)}],
        "singleVisual": {
            "visualType": "slicer",
            "projections": {"Values": [{"queryRef": ref}]},
            "prototypeQuery": {
                "Version": 2,
                "From": [{"Name": "o", "Entity": "オンライン化状況", "Type": 0}],
                "Select": [{"Column": {
                    "Expression": {"SourceRef": {"Source": "o"}},
                    "Property": column,
                }, "Name": ref}],
            },
            "objects": {
                "general":   [{"properties": {"responsive":   lit_bool(True)}}],
                "data":      [{"properties": {"mode":         lit_str("Dropdown")}}],
                "selection": [{"properties": {"singleSelect": lit_bool(single)}}],
                "header":    [{"properties": {"show":         lit_bool(False)}}],
                "items":     [{"properties": {
                    "textSize":   lit_double(14),
                    "fontFamily": lit_str("Arial"),
                }}],
            },
            "vcObjects": {
                "title": [{"properties": {
                    "show":       lit_bool(True),
                    "text":       lit_str(label),
                    "fontColor":  solid(TXT_MAIN),
                    "fontSize":   lit_double(11),
                    "fontFamily": lit_str("Arial"),
                }}],
                "background": HIDE,
                "border": [{"properties": {
                    "show":   lit_bool(True),
                    "color":  solid(GRAY_LINE),
                    "radius": lit_int(RADIUS),
                }}],
            },
        },
    }
    return vc(cfg, [], x, y, w, h, z)


# ============================================================
# 共通サマリーパネル
# ============================================================

def summary_panel(prefix, px, py, pw, *,
                  donut_sz=260, donut_font=32, kpi_font=28, panel_h=780):
    visuals = []
    cx = px + 18
    cw = pw - 36

    visuals.append(shape(f"{prefix}_bg", px, py, pw, panel_h, 0))

    visuals.append(textbox(f"{prefix}_lbl1", cx, py + 18, cw, 48, 1, [
        {"textRuns": [{"value": "26手続き全てのオンライン化が",
                       "textStyle": {"fontSize": "14px", "color": TXT_MAIN,
                                     "fontWeight": "bold", "fontFamily": "Arial"}}]},
        {"textRuns": [{"value": "完了した自治体の割合",
                       "textStyle": {"fontSize": "14px", "color": TXT_MAIN,
                                     "fontWeight": "bold", "fontFamily": "Arial"}}]},
    ]))

    dx = px + (pw - donut_sz) // 2
    dy = py + 80
    visuals.append(donut(f"{prefix}_donut", dx, dy, donut_sz, donut_sz, 1,
                         font_size=donut_font))

    lbl_w = donut_sz - 80
    lbl_x = dx + 40
    lbl_y = dy + donut_sz // 2 - 48
    visuals.append(textbox(f"{prefix}_donut_lbl", lbl_x, lbl_y, lbl_w, 24, 2, [
        {"textRuns": [{"value": "オンライン化完了率",
                       "textStyle": {"fontSize": "11px", "color": TXT_SUB,
                                     "fontFamily": "Arial"}}],
         "horizontalTextAlignment": "center"},
    ]))

    kpi_y = dy + donut_sz + 20
    visuals.append(textbox(f"{prefix}_lbl2", cx, kpi_y, cw, 42, 1, [
        {"textRuns": [{"value": "26手続き全てのオンライン化が",
                       "textStyle": {"fontSize": "12px", "color": TXT_SUB,
                                     "fontFamily": "Arial"}}]},
        {"textRuns": [{"value": "完了した自治体数／全自治体数",
                       "textStyle": {"fontSize": "12px", "color": TXT_SUB,
                                     "fontFamily": "Arial"}}]},
    ]))

    cnt_y = kpi_y + 48
    visuals.append(card_measure(f"{prefix}_cnt_done", cx + 30, cnt_y, 150, 50, 1,
                                "子育て介護26手続完了自治体数", font_size=kpi_font))

    sep_y = cnt_y + 48
    visuals.append(shape(f"{prefix}_sep", cx + 30, sep_y, 150, 2, 1,
                         fill=GRAY_LINE, border=GRAY_LINE, radius=0))

    visuals.append(card_measure(f"{prefix}_cnt_all", cx + 30, sep_y + 6, 150, 50, 1,
                                "自治体数", font_size=kpi_font))

    return visuals


# ============================================================
# ページ1 — 都道府県一覧
# ============================================================

def page1():
    v = []

    # ヘッダー
    v.append(textbox("p1_title", 40, 20, 900, 42, 1, [
        {"textRuns": [
            {"value": TITLE,
             "textStyle": {"fontSize": "20px", "color": TXT_MAIN,
                           "fontWeight": "bold", "fontFamily": "Arial"}},
            {"value": "｜都道府県一覧",
             "textStyle": {"fontSize": "20px", "color": TXT_SUB,
                           "fontFamily": "Arial"}},
        ]},
    ]))
    v.append(shape("p1_hline", 20, 66, 1880, 2, 0.5,
                   fill=GRAY_LINE, border=GRAY_LINE, radius=0))

    # 左サマリーパネル
    v.extend(summary_panel("p1", 30, 80, 370,
                            donut_sz=260, donut_font=32, kpi_font=28, panel_h=870))

    # フッター
    v.append(textbox("p1_date", 40, 960, 250, 20, 1, [
        {"textRuns": [{"value": DATE_STR,
                       "textStyle": {"fontSize": "11px", "color": TXT_MUTED,
                                     "fontFamily": "Arial"}}]},
    ]))
    v.append(textbox("p1_credit", 1740, 960, 160, 20, 1, [
        {"textRuns": [{"value": "デジタル庁",
                       "textStyle": {"fontSize": "11px", "color": TXT_MAIN,
                                     "fontFamily": "Arial"}}],
         "horizontalTextAlignment": "right"},
    ]))

    # 右グリッド — 6列 × 最大9行
    grid_x      = 440
    col_stride  = 243
    col_w       = 225
    tile_h      = 60
    tile_stride = 66
    header_y    = 82
    tile_y0     = 112

    pref_idx = 0
    for col_i, (region, prefs) in enumerate(REGIONS):
        cx = grid_x + col_i * col_stride

        v.append(textbox(f"p1_rh_{col_i}", cx, header_y, col_w, 25, 1, [
            {"textRuns": [{"value": region,
                           "textStyle": {"fontSize": "13px", "color": TXT_SUB,
                                         "fontWeight": "bold",
                                         "fontFamily": "Arial"}}]},
        ]))

        for row_i, pref in enumerate(prefs):
            ty = tile_y0 + row_i * tile_stride
            v.append(pref_tile(f"p1_pf_{pref_idx:02d}", cx, ty, col_w, tile_h, 1, pref))
            pref_idx += 1

    page_cfg = {"objects": {"background": [{"properties": {
        "color":        solid(BG_WHITE),
        "transparency": lit_double(0),
    }}]}}

    return {
        "config":      json.dumps(page_cfg, ensure_ascii=False),
        "displayName": "都道府県一覧",
        "displayOption": 1,
        "filters":     json.dumps([], ensure_ascii=False),
        "height":      1080.0,
        "name":        "ReportSection_page1",
        "ordinal":     0,
        "visualContainers": v,
        "width":       1920.0,
    }


# ============================================================
# ページ2 — 市区町村一覧
# ============================================================

def page2():
    page_filter = [{
        "name": "flt_subcat",
        "expression": {
            "Column": {
                "Expression": {"SourceRef": {"Entity": "オンライン化状況"}},
                "Property": "サブカテゴリ",
            }
        },
        "type": "Categorical",
        "filter": {
            "Version": 2,
            "From": [{"Name": "o", "Entity": "オンライン化状況", "Type": 0}],
            "Where": [{"Condition": {"In": {
                "Expressions": [{"Column": {
                    "Expression": {"SourceRef": {"Source": "o"}},
                    "Property": "サブカテゴリ"}}],
                "Values": [
                    [{"Literal": {"Value": "'ア.子育て関係'"}}],
                    [{"Literal": {"Value": "'イ.介護関係'"}}],
                ],
            }}}],
        },
        "isHiddenInViewMode": True,
    }]

    v = []

    # ヘッダー
    v.append(textbox("p2_title", 40, 20, 900, 42, 1, [
        {"textRuns": [
            {"value": TITLE,
             "textStyle": {"fontSize": "20px", "color": TXT_MAIN,
                           "fontWeight": "bold", "fontFamily": "Arial"}},
            {"value": "｜市区町村一覧",
             "textStyle": {"fontSize": "20px", "color": TXT_SUB,
                           "fontFamily": "Arial"}},
        ]},
    ]))
    v.append(shape("p2_hline", 20, 66, 1880, 2, 0.5,
                   fill=GRAY_LINE, border=GRAY_LINE, radius=0))

    # 都道府県スライサー
    v.append(slicer("p2_sl_pref", 1580, 14, 200, 48, 1, "都道府県", "各都道府県を選ぶ"))

    # 選択都道府県カード
    v.append(card_measure("p2_pref_name", 50, 90, 310, 40, 1,
                           "選択都道府県", font_size=22))

    # 左サマリーパネル
    v.extend(summary_panel("p2", 30, 135, 350,
                            donut_sz=220, donut_font=28, kpi_font=24, panel_h=710))

    # フッター
    v.append(textbox("p2_date", 40, 1045, 250, 20, 1, [
        {"textRuns": [{"value": DATE_STR,
                       "textStyle": {"fontSize": "11px", "color": TXT_MUTED,
                                     "fontFamily": "Arial"}}]},
    ]))
    v.append(textbox("p2_credit", 1740, 1045, 160, 20, 0, [
        {"textRuns": [{"value": "デジタル庁",
                       "textStyle": {"fontSize": "11px", "color": TXT_MAIN,
                                     "fontFamily": "Arial"}}],
         "horizontalTextAlignment": "right"},
    ]))

    # 凡例
    v.append(textbox("p2_legend", 400, 1020, 700, 25, 0, [
        {"textRuns": [
            {"value": "●",
             "textStyle": {"fontSize": "13px", "color": BLUE, "fontFamily": "Arial"}},
            {"value": " オンライン手続きできる　",
             "textStyle": {"fontSize": "12px", "color": TXT_SUB, "fontFamily": "Arial"}},
            {"value": "●",
             "textStyle": {"fontSize": "13px", "color": GRAY_LINE, "fontFamily": "Arial"}},
            {"value": " オンライン手続きできない　",
             "textStyle": {"fontSize": "12px", "color": TXT_SUB, "fontFamily": "Arial"}},
            {"value": "ー 該当する手続きがない",
             "textStyle": {"fontSize": "12px", "color": TXT_SUB, "fontFamily": "Arial"}},
        ]},
    ]))

    # マトリクステーブル
    matrix_cfg = {
        "name": "p2_matrix",
        "layouts": [{"id": 0, "position": pos(400, 80, 0, 1500, 930)}],
        "singleVisual": {
            "visualType": "pivotTable",
            "projections": {
                "Rows":    [{"queryRef": "o.サブカテゴリ"}, {"queryRef": "o.手続名"}],
                "Columns": [{"queryRef": "o.団体名"}],
                "Values":  [{"queryRef": "o.ステータス記号"}],
            },
            "prototypeQuery": {
                "Version": 2,
                "From": [{"Name": "o", "Entity": "オンライン化状況", "Type": 0}],
                "Select": [
                    {"Column":  {"Expression": {"SourceRef": {"Source": "o"}},
                                 "Property": "サブカテゴリ"},
                     "Name": "o.サブカテゴリ"},
                    {"Column":  {"Expression": {"SourceRef": {"Source": "o"}},
                                 "Property": "手続名"},
                     "Name": "o.手続名"},
                    {"Column":  {"Expression": {"SourceRef": {"Source": "o"}},
                                 "Property": "団体名"},
                     "Name": "o.団体名"},
                    {"Measure": {"Expression": {"SourceRef": {"Source": "o"}},
                                 "Property": "ステータス記号"},
                     "Name": "o.ステータス記号"},
                ],
            },
            "objects": {
                "subTotals": [{"properties": {
                    "rowSubtotals":    lit_bool(False),
                    "columnSubtotals": lit_bool(False),
                }}],
                "grid": [{"properties": {
                    "gridVertical":        lit_bool(True),
                    "gridVerticalColor":   solid("#EEEEEE"),
                    "gridVerticalWeight":  lit_double(1),
                    "gridHorizontal":      lit_bool(True),
                    "gridHorizontalColor": solid("#EEEEEE"),
                    "gridHorizontalWeight": lit_double(1),
                }}],
                "columnHeaders": [{"properties": {
                    "fontSize":   lit_double(10),
                    "fontFamily": lit_str("Arial"),
                    "fontColor":  solid(TXT_MAIN),
                    "bold":       lit_bool(True),
                }}],
                "rowHeaders": [{"properties": {
                    "fontSize":   lit_double(10),
                    "fontFamily": lit_str("Arial"),
                    "fontColor":  solid(TXT_MAIN),
                }}],
                "values": [{"properties": {
                    "fontSize":   lit_double(14),
                    "fontFamily": lit_str("Arial"),
                    "fontColor":  solid(BLUE),
                    "backColor":  solid(BG_WHITE),
                }}],
            },
            "vcObjects": {
                "title":      HIDE,
                "background": [{"properties": {
                    "show":         lit_bool(True),
                    "color":        solid(BG_PANEL),
                    "transparency": lit_double(0),
                }}],
                "border": [{"properties": {
                    "show":   lit_bool(True),
                    "color":  solid(BG_PANEL),
                    "radius": lit_int(RADIUS),
                }}],
                "visualHeader": HIDE,
            },
        },
    }
    v.append(vc(matrix_cfg, [], 400, 80, 1500, 930, 0))

    page_cfg = {"objects": {"background": [{"properties": {
        "color":        solid(BG_WHITE),
        "transparency": lit_double(0),
    }}]}}

    return {
        "config":      json.dumps(page_cfg, ensure_ascii=False),
        "displayName": "市区町村一覧",
        "displayOption": 1,
        "filters":     json.dumps(page_filter, ensure_ascii=False),
        "height":      1080.0,
        "name":        "ReportSection_page2",
        "ordinal":     1,
        "visualContainers": v,
        "width":       1920.0,
    }


# ============================================================
# レポート組み立て
# ============================================================

def build_report():
    report_cfg = {
        "version": "5.44",
        "themeCollection": {
            "baseTheme": {
                "name": "CY23SU08",
                "version": "5.46",
                "type": 2,
            },
            "customTheme": {
                "name": "Digital_Agency_Dashboard_Desig3362615343750506.json",
                "version": "5.46",
                "type": 1,
            },
        },
        "activeSectionIndex": 0,
        "defaultDrillFilterOtherVisuals": True,
        "linguisticSchemaSyncVersion": 2,
        "settings": {
            "useNewFilterPaneExperience":      True,
            "allowChangeFilterTypes":          True,
            "useStylableVisualContainerHeader": True,
            "queryLimitOption":                6,
            "useEnhancedTooltips":             True,
            "exportDataMode":                  1,
            "useDefaultAggregateDisplayName":  True,
        },
    }

    return {
        "config": json.dumps(report_cfg, ensure_ascii=False),
        "layoutOptimization": 0,
        "resourcePackages": [
            {"resourcePackage": {
                "disabled": False,
                "items": [{"name": "CY23SU08",
                           "path": "BaseThemes/CY23SU08.json", "type": 202}],
                "name": "SharedResources",
                "type": 2,
            }},
            {"resourcePackage": {
                "disabled": False,
                "items": [{"name": "Digital_Agency_Dashboard_Desig3362615343750506.json",
                           "path": "Digital_Agency_Dashboard_Desig3362615343750506.json",
                           "type": 201}],
                "name": "RegisteredResources",
                "type": 1,
            }},
        ],
        "sections": [page1(), page2()],
        "theme": "Digital_Agency_Dashboard_Desig3362615343750506.json",
    }


# ============================================================
# バリデーション
# ============================================================

def validate(report):
    errors = []

    def try_parse(s, path):
        try:
            return json.loads(s)
        except json.JSONDecodeError as e:
            errors.append(f"{path}: {e}")
            return None

    try_parse(report["config"], "report.config")
    names = set()

    for si, sec in enumerate(report["sections"]):
        sp = f"sections[{si}]"
        try_parse(sec["config"],  f"{sp}.config")
        try_parse(sec["filters"], f"{sp}.filters")

        for vi, container in enumerate(sec.get("visualContainers", [])):
            vp = f"{sp}.vc[{vi}]"
            cfg = try_parse(container["config"],  f"{vp}.config")
            try_parse(container["filters"], f"{vp}.filters")

            if cfg:
                n = cfg.get("name", "")
                if n in names:
                    errors.append(f"{vp}: 重複名 '{n}'")
                names.add(n)

                pq = cfg.get("singleVisual", {}).get("prototypeQuery")
                if pq and pq.get("Version") != 2:
                    errors.append(f"{vp}: prototypeQuery.Version != 2")

    return errors


# ============================================================
# エントリーポイント
# ============================================================

def main():
    here = os.path.dirname(os.path.abspath(__file__))
    out  = os.path.join(here,
                        "26_administrative_procedures_online.Report",
                        "report.json")

    report = build_report()

    errs = validate(report)
    if errs:
        for e in errs:
            print(f"  ERROR: {e}", file=sys.stderr)
        sys.exit(1)

    text = json.dumps(report, ensure_ascii=False, indent=2)
    json.loads(text)  # ラウンドトリップ確認

    os.makedirs(os.path.dirname(out), exist_ok=True)
    with open(out, "w", encoding="utf-8") as f:
        f.write(text)

    p1 = len(report["sections"][0]["visualContainers"])
    p2 = len(report["sections"][1]["visualContainers"])
    print(f"OK  {out}")
    print(f"    ページ1: {p1} ビジュアル / ページ2: {p2} ビジュアル / {len(text):,} bytes")


if __name__ == "__main__":
    main()
